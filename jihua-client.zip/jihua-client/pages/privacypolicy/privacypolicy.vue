<template>
	<view>
		<view class="topBar">
			<view>隐&nbsp;私&nbsp;政&nbsp;策</view>
		</view>
		
		<view class="logo-father">
			<img class="logo" src="~@/static/personcenter_icon/bwlogo.png" alt="" />
		</view>
		
		<view class="body">
			<p><span style="color: white; width: 30rpx;">空格</span>欢迎您使用记划服务我们珍视您在向我们提供您的个人信息时对我们的信任，我们将按照本隐私政策处理您的个人信息并保障您信息的安全。</p>
			<p><span style="color: white; width: 30rpx;">空格</span>请您务必认真阅读本隐私政策，在确认充分了解后再使用记划服务。</p>
			<p style="margin-top: 20rpx; margin-bottom: 7rpx;">（1）权限控制</p>
			<p><span style="color: white; width: 30rpx;">空格</span>根据自己的需求，我们可以让自己允许的人得到自己的位置信息，除此之外，我们的信息采用的是覆盖的方法，不会对用户的位置信息得到保留。</p>
			<p style="margin-top: 20rpx; margin-bottom: 7rpx;">（2）重要数据加密</p>
			<p><span style="color: white; width: 30rpx;">空格</span>对一些重要的数据按一定的算法进行加密，如用户口令、重要参数等。</p>
			<p style="margin-top: 20rpx; margin-bottom: 7rpx;">（3）数据备份</p>
			<p><span style="color: white; width: 30rpx;">空格</span>允许用户进行数据的备份和恢复，以弥补数据的破坏和丢失。</p>
			<p style="margin-top: 20rpx; margin-bottom: 7rpx;">（4）记录日志</p>
			<p><span style="color: white; width: 30rpx;">空格</span>本系统应该能够记录系统运行时所发生的所有错误，包括本机错误和网络错误。这些错误记录便于查找错误的原因。日志同时记录用户的关键性操作信息。</p>
			<p style="margin-top: 20rpx; margin-bottom: 7rpx;">（5）您的权利</p>
			<p><span style="color: white; width: 30rpx;">空格</span>按照中国相关的法律、法规、标准，以及其他国家、地区的通行做法，我们保障您对自己的个人信息行使以下权利：</p>
			<p><span style="color: white; width: 30rpx;">空格</span>1、访问您的个人信息</p>
			<p><span style="color: white; width: 30rpx;">空格</span>2、更正您的个人信息</p>
			<p><span style="color: white; width: 30rpx;">空格</span>3、删除您的个人信息</p>
			<p><span style="color: white; width: 30rpx;">空格</span>4、改变您授权同意的范围</p>
			<p><span style="color: white; width: 30rpx;">空格</span>5、个人信息主体注销账户</p>
			<p><span style="color: white; width: 30rpx;">空格</span>6、本隐私权政策如何更新</p>
			<p style="margin-top: 20rpx; margin-bottom: 7rpx;">（6）您的个人信息如何在全球范围转移</p>
			<p><span style="color: white; width: 30rpx;">空格</span>原则上，我们在中华人民共和国境内收集和产生的个人信息，将存储在中华人民共和国境内。 由于我们通过遍布全球的资源和服务器提供产品或服务，这意味着，在获得您的授权同意后，您的个人信息可能会被转移到您使用产品或服务所在国家/地区的境外管辖区，或者受到来自这些管辖区的访问。 此类管辖区可能设有不同的数据保护法，甚至未设立相关法律。在此类情况下，我们会确保您的个人信息得到在中华人民共和国境内足够同等的保护。例如，我们会请求您对跨境转移个人信息的同意，或者在跨境数据转移之前实施数据去标识化等安全举措。
			<p style="margin-top: 20rpx; margin-bottom: 7rpx;">（7）本隐私权政策如何更新</p>
			<p><span style="color: white; width: 30rpx;">空格</span>我们可能适时会对本隐私权政策进行调整或变更，本隐私权政策由“记划”小组解释，除法律法规或监管规定另有强制性规定外，经调整或变更的内容一经通知或公布后的7日后生效。如您在隐私权政策调整或变更后继续使用我们提供的任一服务或访问我们相关网站的，我们相信这代表您已充分阅读、理解并接受修改后的隐私权政策并受其约束。</p>
			<p><span style="color: white; width: 30rpx;">空格</span></p>
		</view>
	</view>
</template>

<script>
	export default {
		mounted() {
			
		},
		data() {
			return {
				
			}
		},
		methods: {
			
		}
	}
</script>

<style>
	.topBar view {
		margin-top: 50rpx;
		font-size: 30px;
		text-align: center;
	}
	.body {
		margin-left: 30rpx;
		margin-right: 30rpx;
		margin-top: 30rpx;
	}
	.logo-father{
		display: flex;
		justify-content: space-between;
	}
	.logo {
		width: 300rpx;
		height: 300rpx;
		margin-left: auto;
		margin-right: auto;
	}
</style>
